from datetime import datetime
from pathlib import Path

import joblib
import pandas as pd
from flask import Flask, flash, redirect, render_template, render_template_string, request, send_file, url_for
from werkzeug.utils import secure_filename


BASE_DIR = Path(__file__).resolve().parent
print(BASE_DIR)
MODEL_PATH = BASE_DIR / "../models" / "network_intrusion_pipeline.joblib"
OUTPUT_DIR = BASE_DIR / "outputs"
UPLOAD_DIR = BASE_DIR / "uploads"
TRAIN_PATH = BASE_DIR / "../dataset" / "Train_data.csv"
TARGET_COLUMN = "class"

OUTPUT_DIR.mkdir(exist_ok=True)
UPLOAD_DIR.mkdir(exist_ok=True)

app = Flask(__name__)
app.secret_key = "network-intrusion-demo"

def expected_feature_columns():
    if not TRAIN_PATH.exists():
        return None
    return pd.read_csv(TRAIN_PATH, nrows=1).drop(columns=[TARGET_COLUMN]).columns.tolist()


def predict_dataframe(df):
    if not MODEL_PATH.exists():
        raise FileNotFoundError(
            "Model file not found. Run the notebook first so it creates "
            "'models/network_intrusion_pipeline.joblib'."
        )

    feature_columns = expected_feature_columns()
    if feature_columns is None:
        raise FileNotFoundError("Training CSV not found, so expected feature columns cannot be checked.")

    missing_columns = [column for column in feature_columns if column not in df.columns]
    if missing_columns:
        raise ValueError(f"Uploaded CSV is missing required columns: {missing_columns[:8]}")

    model = joblib.load(MODEL_PATH)
    features = df[feature_columns]
    predictions = model.predict(features)

    result_df = df.copy()
    result_df["predicted_class"] = pd.Series(predictions).map({0: "normal", 1: "anomaly"})

    classifier = model.named_steps.get("model")
    if hasattr(classifier, "predict_proba"):
        result_df["anomaly_probability"] = model.predict_proba(features)[:, 1]

    return result_df


@app.get("/")
def index():
    return render_template("index.html", result=None)


@app.get("/download/<path:filename>")
def download_file(filename):
    file_path = OUTPUT_DIR / secure_filename(filename)
    if not file_path.exists():
        flash("Prediction file was not found.")
        return redirect(url_for("index"))
    return send_file(file_path, as_attachment=True)


@app.post("/predict")
def predict():
    uploaded_file = request.files.get("csv_file")
    if uploaded_file is None or uploaded_file.filename == "":
        flash("Please choose a CSV file.")
        return redirect(url_for("index"))

    filename = secure_filename(uploaded_file.filename)
    if not filename.lower().endswith(".csv"):
        flash("Only CSV files are supported.")
        return redirect(url_for("index"))

    upload_path = UPLOAD_DIR / filename
    uploaded_file.save(upload_path)

    try:
        input_df = pd.read_csv(upload_path)
        result_df = predict_dataframe(input_df)
    except Exception as exc:
        flash(str(exc))
        return redirect(url_for("index"))

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_path = OUTPUT_DIR / f"web_predictions_{Path(filename).stem}_{timestamp}.csv"
    result_df.to_csv(output_path, index=False)

    counts = result_df["predicted_class"].value_counts()
    preview_columns = [
        column
        for column in ["protocol_type", "service", "flag", "predicted_class", "anomaly_probability"]
        if column in result_df.columns
    ]
    preview_html = result_df[preview_columns].head(25).to_html(index=False, classes="preview-table")

    result = {
        "total_rows": len(result_df),
        "normal_count": int(counts.get("normal", 0)),
        "anomaly_count": int(counts.get("anomaly", 0)),
        "output_file": str(output_path.relative_to(BASE_DIR)),
        "output_filename": output_path.name,
        "preview_html": preview_html,
    }
    return render_template("index.html", result=result)


if __name__ == "__main__":
    app.run(debug=True)
