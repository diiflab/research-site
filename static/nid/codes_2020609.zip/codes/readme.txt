## Run Locally

Install Anaconda/mini conda via official link: https://www.anaconda.com/docs/getting-started/installation

Open terminal/command prompt to create conda environment:
```bash
conda create -n nid python=3.12
```

Activate `nid` environment:
```bash
conda activate nid
```

Install Python dependencies:

```bash
pip install -r requirements.txt
```

Run the notebook:

```bash
jupyter notebook network-intrusion-detection-using-ml.ipynb
```

Run the notebook cells until the model is saved to:

```text
models/network_intrusion_pipeline.joblib
```

## Run the Flask Web App

Make sure the notebook has already created:

```text
models/network_intrusion_pipeline.joblib
```

Then run:

```bash
python webapp/app.py
```

Open:

```text
http://localhost:5000
```

Upload one of these CSV files:

- `dataset/Test_data.csv`
- `outputs/sample_network_connections.csv`
- `outputs/web_demo_upload.csv`

The app will save prediction results under `webapp/outputs/`.
